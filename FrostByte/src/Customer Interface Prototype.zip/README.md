
  # Customer Interface Prototype

  This is a code bundle for Customer Interface Prototype. The original project is available at https://www.figma.com/design/D5zrTBI0vMkHL1GWsYCSj8/Customer-Interface-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  